<?php
	function db_connect(){
		return  mysqli_connect("210.16.190.83","sq_runton","my090720140","sq_runton");
	}
?>